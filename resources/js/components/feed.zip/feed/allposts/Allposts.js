import "vue-skeletor/dist/vue-skeletor.css";
import { Skeletor } from "vue-skeletor";
import axios from "axios";

export default {
    components: {
        Skeletor,
    },
    props: {
        user: {
            type: Object
        },
    },
    data() {
        return {
            allPosts: [], // Placeholder for all posts data
            currentUser: {}, // Placeholder for the current user data
            newComment: '' // Placeholder for new comment text
        };
    },
    methods: {
        async getUserData() {
            try {
                const response = await axios.get('/userposts/all', {
                    withCredentials: true, // Ensures cookies (like CSRF token) are sent with the request
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'), // Retrieves CSRF token from a meta tag
                    },
                });
                this.allPosts = response.data;
            } catch (error) {
                console.error('Error fetching data:', error);
                // Handle error appropriately
            }
        },
    },
    filters: {
        formatTime(value) {
            // Format time logic (e.g., using moment.js)
            return value; // Placeholder
        }
    },
    mounted() {
        this.getUserData();
    },
    // data() {
    //     return {
    //         allPosts: [], // Placeholder for all posts data
    //         currentUser: {}, // Placeholder for the current user data
    //         newComment: '' // Placeholder for new comment text
    //     };
    // },
    // mounted() {
    //     // Fetch all posts data from the "all" route
    //     axios.get('/userposts/all', { withCredentials: true })
    //         .then(response => {
    //             this.allPosts = response.data;
    //         })
    //         .catch(error => {
    //             console.error('Error fetching posts:', error);
    //         });

    //     // Mock current user data for demonstration
    //     this.currentUser = {
    //         id: 1,
    //         name: 'John Doe',
    //         avatar: 'https://example.com/avatar.jpg'
    //         // Add more properties as needed
    //     };
    // },
    // filters: {
    //     formatTime(value) {
    //         // Format time logic (e.g., using moment.js)
    //         return value; // Placeholder
    //     }
    // }
};