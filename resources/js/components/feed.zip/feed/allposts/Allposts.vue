<template>
    <div>
        <div v-for="post in allPosts" :key="post.id" class="post shadow mb-4 rounded-2">
            <!-- Post heading section -->
            <!-- ... (same as previous template) ... -->

            <!-- Post content based on type -->
            <div v-if="post.type === 'text'" class="post-description">
                <p class="px-3">{{ post.post_text }}</p>
                <!-- Add more text post details as needed -->
            </div>
            <div v-else-if="post.type === 'image'" class="post-file">
                <img :src="post.post_link_image" alt="image" class="image-file pointer img-fluid">
                <!-- Add more image post details as needed -->
            </div>
            <!-- Add more conditions for other post types -->

            <!-- Like and comment counts -->
            <div class="like-comment-count d-flex justify-content-between p-3">
                <div class="like-count"><span><i class="bi bi-hand-thumbs-up"></i> {{ post.likes_count }}</span></div>
                <div class="comment-count"><span><i class="bi bi-chat pe-2"></i> {{ post.comments_count }}</span></div>
            </div>

            <!-- Interaction buttons (like, comment, share) -->
            <div class="post-reach row mb-3">
                <!-- Add interaction buttons as needed -->
            </div>

            <!-- Comment box -->
            <div class="comment-box p-2 px-3 d-flex gap-2 align-items-center">
                <div class="user-icon">
                    <img class="avatar rounded-circle" :src="currentUser.avatar" width="48" height="48"
                        :alt="currentUser.name + ' profile picture'">
                </div>
                <div class="comment-form w-100">
                    <form action="">
                        <textarea v-model="newComment" rows="1" placeholder="Write a comment and press enter"
                            class="rounded-5 w-100 d-block p-3 border-opacity-25 border-secondary "></textarea>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>



<script>

import Allposts from "./Allposts.js";

export default Allposts;
</script>
  
<style scoped>
/* CSS styles for all posts */
</style>  